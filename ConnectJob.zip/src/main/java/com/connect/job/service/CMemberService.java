package com.connect.job.service;

public interface CMemberService {

}
