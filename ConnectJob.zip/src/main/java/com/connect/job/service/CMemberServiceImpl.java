package com.connect.job.service;

public class CMemberServiceImpl implements CMemberService {

}
