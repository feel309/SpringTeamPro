package com.connect.job.service;

import org.springframework.stereotype.Service;

@Service
public class CalendarServiceImpl implements CalendarService {

}
